#ifndef __PRINT_H__
#define __PRINT_H__

#include <stdlib.h>
#include <stdio.h>

void
print_newline();

void
print_hyphen_line(int repeat);

#endif  // __PRINT_H__
