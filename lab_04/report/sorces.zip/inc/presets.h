#ifndef __PRESETS_H__
#define __PRESETS_H__

#define MAIN_STACK_SIZE 50

#define MIN_MENU_KEY 0
#define MAX_MENU_KEY 9

#define MIN(x, y) x > y ? y : x;

#define MAX(x, y) x > y ? x : y;

#endif  // __PRESETS_H__
