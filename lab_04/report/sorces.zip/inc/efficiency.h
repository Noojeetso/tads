#ifndef __EFFICIENCY_H__
#define __EFFICIENCY_H__

#include "stack.h"
#include <time.h>

#define ITERATIONS 100

void
print_results(void);

#endif  // __EFFICIENCY_H__
