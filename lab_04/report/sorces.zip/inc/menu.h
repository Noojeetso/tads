#ifndef __MENU_H__
#define __MENU_H__

#include <limits.h>
#include "efficiency.h"
#include "stack.h"

int
menu_loop(array_stack_t *array_stack, list_stack_t * list_stack, adress_array_t *adress_array);

#endif  // __MENU_H__
